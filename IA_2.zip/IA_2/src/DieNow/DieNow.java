/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package DieNow;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import javax.swing.ImageIcon;

/**
 *
 * @author 40474
 */
public class DieNow {

    private int[][] n = new int[13][13];
    private int p1r, p1c, p2r, p2c, rules;
    private boolean[][] f = new boolean[13][13];
    private boolean going;
    private String p1n, p2n;

    public void setP1n(String p1n) {
        this.p1n = p1n;
    }

    public void setP2n(String p2n) {
        this.p2n = p2n;
    }

    public String getP1n() {
        return p1n;
    }

    public String getP2n() {
        return p2n;
    }

    class Info {

        String name;
        int wins, loses;
        double winrate;

        @Override
        public String toString() {
            return (name + "," + wins + "," + loses + "," + winrate);
        }
    }

    public DieNow() {
        n = new int[13][13];
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 13; j++) {
                f[i][j] = true;
                if (i % 2 == 0 && j % 2 == 0) {
                    n[i][j] = 1;
                } else {
                    if (i == 0 || j == 0 || i == 12 || j == 12) {
                        n[i][j] = -1;
                    } else {
                        n[i][j] = 0;
                    }
                }
            }
        }
        p1r = 1;
        p1c = 1;
        p2r = 11;
        p2c = 11;
        n[1][1] = 9;
        n[11][11] = 9;
        going = true;
        rules = 1;
    }

    public void Reset() {
        n = new int[13][13];
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 13; j++) {
                f[i][j] = true;
                if (i % 2 == 0 && j % 2 == 0) {
                    n[i][j] = 1;
                } else {
                    if (i == 0 || j == 0 || i == 12 || j == 12) {
                        n[i][j] = -1;
                    } else {
                        n[i][j] = 0;
                    }
                }
            }
        }
        p1r = 1;
        p1c = 1;
        p2r = 11;
        p2c = 11;
        n[1][1] = 9;
        n[11][11] = 9;
        going = true;
    }

    public boolean Connect(int player, int facing) {
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 13; j++) {
                f[i][j] = true;
            }
        }
        int r, c, a, b;
        r = 0;
        c = 0;
        if (facing == 1) {
            c = 1;
        } else if (facing == 2) {
            r = 1;
        } else if (facing == 3) {
            c = -1;
        } else if (facing == 4) {
            r = -1;
        }
        if (player == 1) {
            a = p1r + r;
            b = p1c + c;
        } else {
            a = p2r + r;
            b = p2c + c;
        }
        boolean f = false;
        if (check(a, b) && n[a][b] != -1) {
            n[a][b] = -1;
            f = true;
        }
        if (test(p1r, p1c) == false) {
            going = false;
        }
        return f;
    }

    public boolean MovePlayer(int player, int direction) {
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 13; j++) {
                f[i][j] = true;
            }
        }
        int r1, c1, r2, c2, a, b;
        r1 = 0;
        c1 = 0;
        r2 = 0;
        c2 = 0;
        if (direction == 1) {
            c1 = 2;
            c2 = 1;
        } else if (direction == 2) {
            r1 = 2;
            r2 = 1;
        } else if (direction == 3) {
            c1 = -2;
            c2 = -1;
        } else if (direction == 4) {
            r1 = -2;
            r2 = -1;
        }
        boolean f = false;
        if (player == 1) {
            a = p1r + r1;
            b = p1c + c1;
            if (check(a, b) && n[p1r + r2][p1c + c2] != -1 && n[a][b] != 9) {
                n[p1r][p1c] = 0;
                p1r = a;
                p1c = b;
                n[p1r][p1c] = 9;
                f = true;
            }

        } else {
            a = p2r + r1;
            b = p2c + c1;
            if (check(a, b) && n[p2r + r2][p2c + c2] != -1 && n[a][b] != 9) {
                n[p2r][p2c] = 0;
                p2r = a;
                p2c = b;
                n[p2r][p2c] = 9;
                f = true;

            }
        }
        return f;
    }

    public boolean check(int a, int b) {
        boolean x = false;
        if (a < 13 && a > -1 && b < 13 && b > -1 && f[a][b]) {
            x = true;
        }
        return x;
    }

    public boolean test(int r, int c) {
        f[r][c] = false;
        int r1, c1, r2, c2, a, b;
        boolean x = false;
        for (int i = 1; i <= 4; i++) {
            r1 = 0;
            c1 = 0;
            r2 = 0;
            c2 = 0;
            if (i == 1) {
                c1 = 2;
                c2 = 1;
            } else if (i == 2) {
                r1 = 2;
                r2 = 1;
            } else if (i == 3) {
                c1 = -2;
                c2 = -1;
            } else if (i == 4) {
                r1 = -2;
                r2 = -1;
            }
            if (check(r + r1, c + c1) && n[r + r2][c + c2] != -1) {
                if (n[r + r1][c + c1] == 9) {
                    x = true;
                } else if (test(r + r1, c + c1)) {
                    x = true;
                }
            }
        }
        return x;
    }

    public int count(int r, int c) {
        f[r][c] = false;
        int r1, c1, r2, c2, a, b;
        int x = 0;
        int y = 0;
        for (int i = 1; i <= 4; i++) {
            r1 = 0;
            c1 = 0;
            r2 = 0;
            c2 = 0;
            if (i == 1) {
                c1 = 2;
                c2 = 1;
            } else if (i == 2) {
                r1 = 2;
                r2 = 1;
            } else if (i == 3) {
                c1 = -2;
                c2 = -1;
            } else if (i == 4) {
                r1 = -2;
                r2 = -1;
            }
            if (n[r + r2][c + c2] != -1 && f[r + r2][c + c2]) {
                y++;
                f[r + r2][c + c2] = false;
            }
            if (check(r + r1, c + c1) && n[r + r2][c + c2] != -1 && n[r + r1][c + c1] != 9) {
                x += count(r + r1, c + c1);
            }
        }
        return x + y;

    }

    public boolean isGoing() {
        return going;
    }

    public int[] winner() {
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 13; j++) {
                f[i][j] = true;
            }
        }
        int p1 = count(p1r, p1c);
        int p2 = count(p2r, p2c);
        int x = 0;
        if (p1 > p2) {
            x = 1;
        } else if (p2 > p1) {
            x = 2;
        } else {
            x = 3;
        }
        int[] s = new int[3];
        s[0] = x;
        s[1] = p1;
        s[2] = p2;
        return s;
    }

    public String println() {
        String s = "";
        String x = "";
        for (int i = 0; i < 13; i++) {
            for (int j = 0; j < 13; j++) {
                if (n[i][j] == 1) {
                    x = "I";
                } else if (n[i][j] == -1) {
                    x = "X";
                } else if (n[i][j] == 9) {
                    x = "P";
                } else if (n[i][j] == 0 && i % 2 == 1 && j % 2 == 1) {
                    x = "O";
                } else if (n[i][j] == 0) {
                    x = "-";
                }
                s += x + " ";
            }
            s += "\n";
        }
        return s;
    }

    public String getP1() {
        return p1r + " " + p1c;
    }

    public String getP2() {
        return p2r + " " + p2c;
    }

    public String[] file(String w, String l) {
        List<Info> a = new ArrayList();
        File file = new File("/Users/40474/NetBeansProjects/IA_2/src/DieNow/Files/TestSheet.csv");
        if (!file.exists()) {
            try {
                file.createNewFile();
                System.out.println("File created");
            } catch (IOException ex) {
                System.out.println("Input/Output excpetion");
            }
        } else {
            System.out.println("File exists");
        }
        FileWriter out;
        BufferedWriter write;
        FileReader in;
        BufferedReader read;
        String s;
        String re[] = new String[2];
        boolean w1 = true;
        boolean l1 = true;
        try {
            in = new FileReader(file);
            read = new BufferedReader(in);
            s = read.readLine();
            while ((s = read.readLine()) != null) {
                String[] temp = s.split(",");
                Info f = new Info();
                f.name = temp[0];
                f.wins = Integer.parseInt(temp[1]);
                f.loses = Integer.parseInt(temp[2]);
                f.winrate = Double.parseDouble(temp[3]);
                if (f.name.equals(w)) {
                    f.wins += 1;
                    f.winrate = (double) (f.wins) / (double) (f.wins + f.loses) * 100;
                    f.winrate = Double.parseDouble(String.format("%.1f", f.winrate));
                    w1 = false;
                    re[0] = f(f.toString());
                }
                if (f.name.equals(l)) {
                    f.loses += 1;
                    f.winrate = (double) (f.wins) / (double) (f.wins + f.loses) * 100;
                    f.winrate = Double.parseDouble(String.format("%.1f", f.winrate));
                    l1 = false;
                    re[1] = f(f.toString());
                }
                a.add(f);
            }
        } catch (FileNotFoundException ex) {
            System.out.println("File not found");
        } catch (IOException ex) {
            System.out.println("Input/Output expection");
        }
        if (w1) {
            Info f = new Info();
            f.name = w;
            f.wins = 1;
            f.loses = 0;
            f.winrate = 1 / (double) 1 * 100;
            a.add(f);
            re[0] = f(f.toString());
        }
        if (l1) {
            Info f = new Info();
            f.name = l;
            f.wins = 0;
            f.loses = 1;
            f.winrate = 0 / (double) 1 * 100;
            a.add(f);
            re[1] = f(f.toString());
        }
        try {
            out = new FileWriter(file);
            write = new BufferedWriter(out);
            write.write("Names,Wins,Loses,WinRate");
            write.newLine();
            while (!a.isEmpty()) {
                write.write(a.get(0).toString());
                write.newLine();
                a.remove(0);
            }
            write.close();
            out.close();
        } catch (FileNotFoundException ex) {
            System.out.println("File not found");
            ex.getMessage();

        } catch (IOException ex) {
            System.out.println("Input/Output expection");

        }
        return re;
    }

    public String f(String s) {
        String[] t = s.split(",");
        String n = "";
        for (int i = 0; i < t.length; i++) {
            n += (t[i] + "     ");
        }
        return n;
    }

    public ImageIcon getRules(int x) {
        ImageIcon i = null;
        if (x == 0) {
            if (rules > 1) {
                rules--;
            }
        } else {
            if (rules < 4) {
                rules++;
            }
        }
        String s = "/Image/Rule" + rules + ".png";
        i = new ImageIcon(getClass().getResource(s));
        return i;
    }

    public ImageIcon getImage(int r, int c) {
        ImageIcon x = null;
        if ((n[r][c] == 9) && (p1r == r) && (p1c == c)) {
            x = new ImageIcon(getClass().getResource("/Image/Player1.png"));
        } else if ((n[r][c] == 9) && (p2r == r) && (p2c == c)) {
            x = new ImageIcon(getClass().getResource("/Image/Player2.png"));
        } else if ((n[r][c] == -1) && (r % 2 == 0)) {
            x = new ImageIcon(getClass().getResource("/Image/WallH.png"));
        } else if ((n[r][c] == -1) && (r % 2 == 1)) {
            x = new ImageIcon(getClass().getResource("/Image/WallV.png"));
        }
        return x;
    }
}
